#' Path plot of BCPA output
#' 
#' Plots the animal's trajectory, with segments color-coded according to the time scale / auto-correlation of the BCPA output, and width of segments proportional to the estimated mean of the BCPA.  
#' 
#' @param Data the track data to be plotted - most typically, output of the \code{\link{GetVT}} function.
#' @param windowsweep \code{windowsweep} object, i.e. the output of the \code{\link{WindowSweep}} function.
#' @param type whether to plot smooth or flat bcpa output
#' @param clusterwidth for flat BCPA, this is the temporal range within which change points are considered to be within the same cluster. 
#' @param {taulegend,mulegend} whether to plot a legend for time-scale and mu.
#' @param {tauwhere,muwhere} where to place the legend for the time-scale and mu.  Can be one of "nowhere", "top", "bottom", "left", "right", "topleft", "topright", "bottomright", "bottomleft".
#' @param n.legend number of labels in legend. 
#' @param ncol.legend number of columns in the legend.
#' @param bty.legend whether to draw a box around the legend.
#' @param palette character string for time scale palette (default "topo.colors").  See \link{\code{palette}}. 
#' @param ... additional arguments to pass to the \code{plot} base function.
#' @author Eliezer Gurarie
#' @examples
#' if(!exists("Simp.ws"))
#' {
#'  data(Simp)
#'  Simp.ws <- WindowSweep(GetVT(Simp), "V*cos(Theta)", windowsize = 50, windowstep = 1, progress=TRUE)
#' }
#' 
#' PathPlot(Simp, Simp.ws, n.legend=3)
#' PathPlot(Simp, Simp.ws, type="flat", clusterwidth=3, taulegend=TRUE, mulegend=TRUE)

PathPlot.bcpa <-  function (Data, windowsweep, type=c("smooth", "flat")[1], clusterwidth = 1, taulegend = TRUE, tauwhere = "topleft", mulegend = TRUE, muwhere = "bottomright", n.legend = 5, ncol.legend = 1, bty.legend="n", palette = "topo.colors", ...) 
{
  if(!("Z" %in% names(Data)))
    z <- Data$X + 1i*Data$Y else z <- Data$Z
  
  if(type=="flat")
    pp <- PartitionParameters(windowsweep, type = type, clusterwidth=clusterwidth)
  
  if(type == "smooth")  
    if("pp.smooth" %in% names(windowsweep)) pp <- windowsweep$pp.smooth else pp <- PartitionParameters(windowsweep, type = type)
  
  Segments <- function(z, col=col, lwd=lwd)
  {
    n <- length(z)
    segments(Re(z[-n]), Im(z[-n]), Re(z[-1]), Im(z[-1]), col=col, lwd=lwd)
  }  
  
  mu.hat <- pp$mu.hat
  rho.hat <- pp$rho.hat
  
  rho.max <- max(rho.hat, na.rm=1)
  rho.int <- round(rho.hat/rho.max * 999 + 1)
  
  eval(parse(text=paste("palette(",palette,"(1000)",")")))
  plot(z, asp=1, pch=19, cex=0.5, col="grey", ...)
 # points(z[c(1,length(z))], pch=c(24, 23), bg=c("green", "red"), cex=2, lwd=1.5, col="darkgrey")
  
  Segments(z, col=rho.int, lwd=abs(mu.hat/max(mu.hat, na.rm=TRUE))*4)
  
  if(taulegend)
    legend(tauwhere,
           title="time scale", ncol = ncol.legend, bty=bty.legend,
           fill=seq(0,999, length=n.legend) + 1, 
           legend = signif(seq(0, max(rho.hat), length = n.legend),2))
  if(mulegend)
  {
    legend.mus <- seq(min(mu.hat, na.rm=TRUE), max(mu.hat, na.rm=TRUE), length = 4)[-1]
    legend(muwhere,  lty=1, 
           title="mean persistence", ncol = 1,
           legend = round(legend.mus, 1), col = "darkgrey",
           lwd=legend.mus*4/max(mu.hat, na.rm=TRUE), bty=bty.legend)
  }
  palette("default")
}
