MakeLetter <- function(text = "a", where = "topleft", cex = 2, ...)
  legend(where, bty="n", pch=NA, title = text, cex=cex, legend = NA,  ...) 
