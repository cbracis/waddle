reload <- function()
{
  unloadNamespace("waddle")
  unloadNamespace("bcpa")
  unloadNamespace("mrw")
  require(waddle)
}
